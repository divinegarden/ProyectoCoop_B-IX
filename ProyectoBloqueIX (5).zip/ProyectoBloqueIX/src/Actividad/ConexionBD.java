package Actividad;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Clase de utilidad para conectar con la base de datos MySQL 'world'.
 * Cambia los valores de USUARIO y CLAVE por los tuyos.
 */
public class ConexionBD {

    private static final String URL = "jdbc:mysql://localhost:3306/world"; // Dirección de la base de datos
    private static final String USUARIO = "root"; // Cambia si tu usuario es otro
    private static final String CLAVE = "inca.2025";       // Cambia si tu contraseña no está vacía

    /**
     * Método estático para obtener una conexión con la base de datos.
     * @return un objeto Connection o null si falla.
     */
    public static Connection conectar() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(URL, USUARIO, CLAVE);
            System.out.println("✅ Conexión exitosa a la base de datos.");
        } catch (SQLException e) {
            System.err.println("❌ Error al conectar con la base de datos: " + e.getMessage());
        }
        return conn;
    }
    
}
