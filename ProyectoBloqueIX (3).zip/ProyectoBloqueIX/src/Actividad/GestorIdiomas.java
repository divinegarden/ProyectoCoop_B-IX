package Actividad;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase que gestiona las operaciones CRUD sobre la tabla countrylanguage.
 */
public class GestorIdiomas {

    /**
     * Carga los idiomas de un país dado su código.
     * @param codigoPais Código del país (ej. "ESP")
     * @return Lista de idiomas de ese país
     */
    public static List<ModeloIdioma> cargarIdiomas(String codigoPais) {
        List<ModeloIdioma> lista = new ArrayList<ModeloIdioma>();
        String sql = "SELECT Language, IsOfficial, Percentage FROM countrylanguage WHERE CountryCode = ?";

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = ConexionBD.conectar();
            ps = conn.prepareStatement(sql);
            ps.setString(1, codigoPais);
            rs = ps.executeQuery();

            while (rs.next()) {
                String idioma = rs.getString("Language");
                boolean oficial = rs.getString("IsOfficial").equalsIgnoreCase("T");
                double porcentaje = rs.getDouble("Percentage");
                lista.add(new ModeloIdioma(idioma, oficial, porcentaje));
            }
        } catch (SQLException e) {
            System.err.println("❌ Error al cargar idiomas: " + e.getMessage());
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (ps != null) ps.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
        return lista;
    }

    /**
     * Inserta un idioma nuevo para un país.
     */
    public static void insertarIdioma(String codigoPais, ModeloIdioma idioma) {
        String sql = "INSERT INTO countrylanguage (CountryCode, Language, IsOfficial, Percentage) VALUES (?, ?, ?, ?)";

        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = ConexionBD.conectar();
            ps = conn.prepareStatement(sql);
            ps.setString(1, codigoPais);
            ps.setString(2, idioma.getIdioma());
            ps.setString(3, idioma.isEsOficial() ? "T" : "F");
            ps.setDouble(4, idioma.getPorcentaje());
            ps.executeUpdate();
            System.out.println("✅ Idioma insertado correctamente.");

        } catch (SQLException e) {
            System.err.println("❌ Error al insertar idioma: " + e.getMessage());
        } finally {
            try { if (ps != null) ps.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }

    /**
     * Modifica los datos de un idioma ya existente para un país.
     */
    public static void modificarIdioma(String codigoPais, ModeloIdioma idioma) {
        String sql = "UPDATE countrylanguage SET IsOfficial = ?, Percentage = ? WHERE CountryCode = ? AND Language = ?";

        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = ConexionBD.conectar();
            ps = conn.prepareStatement(sql);
            ps.setString(1, idioma.isEsOficial() ? "T" : "F");
            ps.setDouble(2, idioma.getPorcentaje());
            ps.setString(3, codigoPais);
            ps.setString(4, idioma.getIdioma());
            ps.executeUpdate();
            System.out.println("✅ Idioma modificado correctamente.");

        } catch (SQLException e) {
            System.err.println("❌ Error al modificar idioma: " + e.getMessage());
        } finally {
            try { if (ps != null) ps.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }

    /**
     * Elimina un idioma de un país.
     */
    public static void eliminarIdioma(String codigoPais, String idioma) {
        String sql = "DELETE FROM countrylanguage WHERE CountryCode = ? AND Language = ?";

        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = ConexionBD.conectar();
            ps = conn.prepareStatement(sql);
            ps.setString(1, codigoPais);
            ps.setString(2, idioma);
            ps.executeUpdate();
            System.out.println("✅ Idioma eliminado correctamente.");

        } catch (SQLException e) {
            System.err.println("❌ Error al eliminar idioma: " + e.getMessage());
        } finally {
            try { if (ps != null) ps.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }
}
