package Actividad;

import javax.swing.table.AbstractTableModel;
import java.util.List;

/**
 * Modelo personalizado para la tabla de idiomas, usando AbstractTableModel
 */
public class TablaIdiomasModel extends AbstractTableModel {

    private final String[] columnas = {"Lengua", "Oficial", "%"};
    private List<ModeloIdioma> lista;

    public TablaIdiomasModel(List<ModeloIdioma> lista) {
        this.lista = lista;
    }

    public void setDatos(List<ModeloIdioma> nuevaLista) {
        this.lista = nuevaLista;
        fireTableDataChanged();
    }

    public int getRowCount() {
        return lista.size();
    }

    public int getColumnCount() {
        return columnas.length;
    }

    public String getColumnName(int col) {
        return columnas[col];
    }

    public Object getValueAt(int fila, int col) {
        ModeloIdioma idioma = lista.get(fila);
        switch (col) {
            case 0: return idioma.getIdioma();
            case 1: return idioma.isEsOficial() ? "T" : "F";
            case 2: return idioma.getPorcentaje();
            default: return null;
        }
    }

    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return false;
    }

    public ModeloIdioma getIdiomaAt(int fila) {
        return lista.get(fila);
    }
}
