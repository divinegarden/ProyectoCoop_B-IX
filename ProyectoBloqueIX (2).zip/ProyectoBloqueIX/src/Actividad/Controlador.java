package Actividad;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.sql.*;
import java.util.List;
import java.util.Vector;

/**
 * Clase que conecta la interfaz con la lógica de base de datos.
 */
public class Controlador {

    private final Paises vista;

    public Controlador(Paises vista) {
        this.vista = vista;
        inicializarEventos();
        bloquearCamposPais();
        desactivarBotonesLengua();
        cargarPaises();
    }

    private void cargarPaises() {
        DefaultTableModel modelo = (DefaultTableModel) vista.getjTable1().getModel();
        modelo.setRowCount(0);

        String sql = "SELECT Code, Name, Continent, Region FROM country";

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = ConexionBD.conectar();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Vector<String> fila = new Vector<String>();
                fila.add(rs.getString("Code"));
                fila.add(rs.getString("Name"));
                fila.add(rs.getString("Continent"));
                fila.add(rs.getString("Region"));
                modelo.addRow(fila);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista, "Error al cargar países: " + e.getMessage());
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (ps != null) ps.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }

    private void cargarIdiomas(String codigoPais) {
        List<ModeloIdioma> idiomas = GestorIdiomas.cargarIdiomas(codigoPais);
        TablaIdiomasModel modelo = new TablaIdiomasModel(idiomas);
        vista.getjTable2().setModel(modelo);
    }

    private void prepararInsercion() {
        vista.getjTextField15().setText("");
        vista.getjTextField16().setText("");
        vista.getjCheckBox1().setSelected(false);
        activarBotonesLengua();
    }

    private void inicializarEventos() {
        vista.getjButton6().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                prepararInsercion();
            }
        });

        vista.getjButton7().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                eliminarIdioma();
            }
        });

        vista.getjButton8().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                guardarIdioma();
                desactivarBotonesLengua();
            }
        });

        vista.getjButton9().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cancelarEdicion();
                desactivarBotonesLengua();
            }
        });

        vista.getjTable1().getSelectionModel().addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int fila = vista.getjTable1().getSelectedRow();
                    if (fila != -1) {
                        String codigoPais = vista.getjTable1().getValueAt(fila, 0).toString();
                        cargarIdiomas(codigoPais);
                    }
                }
            }
        });
    }

    private void desactivarBotonesLengua() {
        vista.getjButton8().setEnabled(false); // Aceptar
        vista.getjButton9().setEnabled(false); // Cancelar
    }

    private void activarBotonesLengua() {
        vista.getjButton8().setEnabled(true); // Aceptar
        vista.getjButton9().setEnabled(true); // Cancelar
    }

    private void bloquearCamposPais() {
        vista.getjTextField1().setEditable(false);
        vista.getjTextField2().setEditable(false);
        vista.getjTextField3().setEditable(false);
        vista.getjTextField4().setEditable(false);
        vista.getjTextField5().setEditable(false);
        vista.getjTextField6().setEditable(false);
        vista.getjComboBox1().setEnabled(false);
        vista.getjTextField7().setEditable(false);
        vista.getjTextField8().setEditable(false);
        vista.getjTextField9().setEditable(false);
        vista.getjTextField10().setEditable(false);
        vista.getjTextField11().setEditable(false);
        vista.getjTextField12().setEditable(false);
        vista.getjTextField13().setEditable(false);
        vista.getjTextField14().setEditable(false);
    }

    private void guardarIdioma() {
        int fila = vista.getjTable1().getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(vista, "Selecciona un país primero.");
            return;
        }
        String codigoPais = vista.getjTable1().getValueAt(fila, 0).toString();
        String idioma = vista.getjTextField15().getText();
        boolean oficial = vista.getjCheckBox1().isSelected();
        double porcentaje = Double.parseDouble(vista.getjTextField16().getText());

        ModeloIdioma nuevo = new ModeloIdioma(idioma, oficial, porcentaje);
        GestorIdiomas.insertarIdioma(codigoPais, nuevo);
        cargarIdiomas(codigoPais);
    }

    private void eliminarIdioma() {
        int filaPais = vista.getjTable1().getSelectedRow();
        int filaIdioma = vista.getjTable2().getSelectedRow();
        if (filaPais == -1 || filaIdioma == -1) {
            JOptionPane.showMessageDialog(vista, "Selecciona un país y un idioma.");
            return;
        }
        String codigoPais = vista.getjTable1().getValueAt(filaPais, 0).toString();
        String idioma = vista.getjTable2().getValueAt(filaIdioma, 0).toString();

        GestorIdiomas.eliminarIdioma(codigoPais, idioma);
        cargarIdiomas(codigoPais);
    }

    private void cancelarEdicion() {
        prepararInsercion();
    }
}
