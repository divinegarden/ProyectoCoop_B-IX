package Actividad;

/**
 * Clase que representa un idioma en la base de datos countrylanguage.
 * Se usará para intercambiar datos entre la interfaz y la base de datos.
 */
public class ModeloIdioma {

    private String idioma;       // Ej: "Spanish"
    private boolean esOficial;   // true si es oficial, false si no
    private double porcentaje;   // Porcentaje de hablantes

    public ModeloIdioma(String idioma, boolean esOficial, double porcentaje) {
        this.idioma = idioma;
        this.esOficial = esOficial;
        this.porcentaje = porcentaje;
    }

    // Getters y setters
    public String getIdioma() {
        return idioma;
    }

    public void setIdioma(String idioma) {
        this.idioma = idioma;
    }

    public boolean isEsOficial() {
        return esOficial;
    }

    public void setEsOficial(boolean esOficial) {
        this.esOficial = esOficial;
    }

    public double getPorcentaje() {
        return porcentaje;
    }

    public void setPorcentaje(double porcentaje) {
        this.porcentaje = porcentaje;
    }

    public String toString() {
        String texto = idioma + " (";
        if (esOficial) {
            texto += "Oficial";
        } else {
            texto += "No Oficial";
        }
        texto += ", " + porcentaje + "%)";
        return texto;
    }
}
