package Actividad;

/**
 * Clase principal que lanza la aplicación y conecta la vista con el controlador.
 */
public class Main {
    public static void main(String[] args) {
        // Crear la interfaz gráfica
        Paises vista = new Paises();

        // Crear el controlador, que se encarga de la lógica
        Controlador controlador = new Controlador(vista);

        // Mostrar la ventana
        vista.setLocationRelativeTo(null); // Centrar en pantalla
        vista.setVisible(true);
    }
}
