package Actividad;

public class TestConexion {
    public static void main(String[] args) {
        ConexionBD.conectar();
    }
}
